# #from .import views
#
#
# {% extends 'main/base.html' %}
#
# {% block title %}
# Home
# {% endblock %}
#
# {% block content %}
# <h1>Home Page</h1>
# {% endblock %}
